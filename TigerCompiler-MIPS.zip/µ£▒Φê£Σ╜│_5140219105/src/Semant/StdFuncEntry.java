package Semant;

/**
 * Created by zhushunjia on 2016/12/3.
 */
import  Types.*;

public class StdFuncEntry extends FuncEntry {
    public StdFuncEntry(Translate.Level l, Temp.Label lab, RECORD params, Type rt)
    {
        super(l, lab, params, rt);
    }
}
