package Frame;

/**
 * Created by zhushunjia on 2016/12/3.
 */
public class AccessList {
	public Access head;
	public AccessList next;
	
	public AccessList(Access h, AccessList n)
	{
		head = h;	next = n;
	}
}
