package Frag;

/**
 * Created by zhushunjia on 2016/12/3.
 */
public class Frag {
    public Frag next = null;
}
