package Frag;

/**
 * Created by zhushunjia on 2016/12/3.
 */

import Temp.Label;
public class DataFrag extends Frag{
    Label label = null;//��
    public String data = null;//�ַ�������

    public DataFrag(Temp.Label label, String data)
    {
        this.label = label;	this.data = data;
    }
}
