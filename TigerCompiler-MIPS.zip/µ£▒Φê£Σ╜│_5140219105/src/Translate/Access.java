package Translate;

/**
 * Created by zhushunjia on 2016/12/3.
 */

//���˸�Level��Access
public class Access {
    public Level home;
    public Frame.Access acc;//Frame��Access


    Access(Level l, Frame.Access a)
    {
        home = l;
        acc = a;
    }
}
