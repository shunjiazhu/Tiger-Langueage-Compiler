package Temp;

public interface TempMap {public String tempMap(Temp t);}

