package Graph;
public class NodeList {
  public Node head;
  public NodeList tail;
  public NodeList(Node h, NodeList t) {head=h; tail=t;}
}



